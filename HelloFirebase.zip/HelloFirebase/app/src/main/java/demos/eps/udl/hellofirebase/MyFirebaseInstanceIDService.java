package demos.eps.udl.hellofirebase;

import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import java.util.HashMap;
import java.util.Map;


public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

    private static final String TAG = "MyFirebaseIIDService";

    @Override
    public void onTokenRefresh() {
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Refreshed token: " + refreshedToken);

        sendRegistrationToServer(refreshedToken);
    }

    public void sendRegistrationToServer(String token) {

        // TODO: Implement this method to send token to your app server.

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        //DatabaseReference myRef = database.getReference("token");
        DatabaseReference myRef = database.getReference("tokensdevices/tokens");

        //DatabaseReference tokensRef = myRef.child("token");
        myRef.setValue(token);

        //createDevice(token, tokensRef);


        //myRef.push().setValue(token);

        //myRef.setValue(token);


        //myRef.setValue(token);
    }

    private class Device {
        private String token;
        private String type;

        public Device (String tk, String tp)  {
            token = tk;
            type = tp;
        }
    }


    public void createDevice (String tk, DatabaseReference tRef) {

        Map<String, Device> devices = new HashMap<String, Device>();
        devices.put("Emulator", new Device(tk, "Emulator"));

        tRef.setValue(devices);
    }

}
