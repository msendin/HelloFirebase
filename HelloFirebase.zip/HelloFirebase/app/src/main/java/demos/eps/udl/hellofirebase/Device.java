package demos.eps.udl.hellofirebase;

/**
 * Created by Montse on 31/03/2018.
 */

public class Device {

        private String token;
        private String type;

        public Device (String tk, String tp)  {
            token = tk;
            type = tp;
        }
}
